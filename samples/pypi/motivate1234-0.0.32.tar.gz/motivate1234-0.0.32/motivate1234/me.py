def motivate_me():
	print('Great great great')
