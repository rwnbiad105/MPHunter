class send():
    pass